
import os
import psycopg2

DATABASE_URL = os.getenv("DATABASE_URL")

conn = psycopg2.connect(DATABASE_URL)
cursor = conn.cursor()

def init_db():
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        user_id BIGINT PRIMARY KEY,
        is_premium BOOLEAN DEFAULT FALSE,
        referrer BIGINT,
        balance FLOAT DEFAULT 0
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS payments (
        user_id BIGINT,
        txid TEXT,
        verified BOOLEAN DEFAULT FALSE
    )
    """)

    conn.commit()
