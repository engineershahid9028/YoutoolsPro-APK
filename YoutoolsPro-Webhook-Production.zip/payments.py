
import os
import requests
from db import cursor, conn

BINANCE_API_KEY = os.getenv("BINANCE_API_KEY")

def verify_payment(txid):
    # Dummy verification for now
    return True

def process_payment(user_id, txid):
    if verify_payment(txid):
        cursor.execute("UPDATE users SET is_premium=true WHERE user_id=%s", (user_id,))
        conn.commit()
        return True
    return False
