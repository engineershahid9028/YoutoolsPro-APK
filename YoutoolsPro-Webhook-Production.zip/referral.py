
from db import cursor, conn

def reward_referrer(user_id):
    cursor.execute("SELECT referrer FROM users WHERE user_id=%s", (user_id,))
    ref = cursor.fetchone()
    if ref and ref[0]:
        cursor.execute("UPDATE users SET balance = balance + 0.5 WHERE user_id=%s", (ref[0],))
        conn.commit()
