
import os
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler
from handlers import start, paid, balance, button_handler

BOT_TOKEN = os.getenv("BOT_TOKEN")

telegram_app = ApplicationBuilder().token(BOT_TOKEN).build()
telegram_app.add_handler(CommandHandler("start", start))
telegram_app.add_handler(CommandHandler("paid", paid))
telegram_app.add_handler(CommandHandler("balance", balance))
telegram_app.add_handler(CallbackQueryHandler(button_handler))
