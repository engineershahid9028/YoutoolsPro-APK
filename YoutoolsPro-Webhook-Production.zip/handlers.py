
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from payments import process_payment
from referral import reward_referrer

def main_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💎 Premium (5 USDT)", callback_data="premium")],
        [InlineKeyboardButton("🎁 Referral Program", callback_data="referral")],
        [InlineKeyboardButton("🏷 Promo Code", callback_data="promo")]
    ])

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🚀 YoutoolsPro Dashboard", reply_markup=main_menu())

async def paid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    txid = context.args[0]
    if process_payment(user_id, txid):
        reward_referrer(user_id)
        await update.message.reply_text("✅ Payment verified! Premium activated.")
    else:
        await update.message.reply_text("❌ Payment not verified yet.")

async def balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("💰 Balance feature coming soon.")

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
